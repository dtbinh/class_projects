Hello, due to my understanding of this project, I have stemed off into two different diresctions. needleman.cu -> needleman_4.cu were an attempt to parallelize the algorithm, which I worked on until I ran into the four Russians issue.  needleman_5.cu and needleman_6.cu were attempts to run concurrent fasta files, however, I was unable to complete this variation in the time remaining.  please take this into consideration.

Sincerely,
Jake