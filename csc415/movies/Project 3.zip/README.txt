This is a program to recommend movies to a user.

In order to use follow the on screen instructions.  They will allow the user to perform several basic functions.

add movies (addmovies) - adds a movie(s) to the database.
update movie (updatemovie) - allows a movie currently in the database to be updated.
get recommendations (getrecomendations) - allows the user to review movies and get recommendations on movies based on proximity to a critic.
print (print) - outputs all data to a text file.
quit (quit) - quits the program.